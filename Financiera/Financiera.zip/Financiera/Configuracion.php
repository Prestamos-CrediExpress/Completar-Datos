<?php
//Declarar variables globales de la conexion a la base de datos
define('HOST','localhost');//El localhost cambia por la IP del servidor web en linea
define('USER','root'); //Cambia el root por el usuario que nos asignó el servidor
define('PASS',''); //El ps que nos da el servidor
define('DBNAME','tarjetas_credito');//Cambia el nombre de BD por el que asigne el servidor.
?>